import Icon from './Icon';
import AccountMenu from './AccountMenu';
import {initials} from '../lib/format';

// One list of pages for everyone: guests see a lock on pages that need an account (they open a sign-in prompt).
function label(page) {return page.locked?`${page.label} (sign in required)`:page.badge>0?`${page.label}, ${page.badge} ${page.badgeLabel||'unread'}`:undefined;}
function marker(page) {return page.locked?<span className="nav-lock"><Icon name="lock"/></span>:page.badge>0?<span className="nav-badge" aria-hidden="true">{page.badge}</span>:null;}

// Client view: the profile at the bottom opens the account menu (records, data sharing, saved chats, Actions, sign out).
export default function Sidebar({session,name,current,pages,menu,onSignOut,onSignIn,subtitle='Signed in'}) {
  // name is null while it loads: a placeholder holds its place instead of generic text that later changes
  const profile=<>{session&&name?<span className="session-avatar initials" aria-hidden="true">{initials(name)}</span>:<span className="session-avatar"><Icon name="user"/></span>}
    <span className="sidebar-who">{session&&name===null?<><span className="skeleton-text" aria-hidden="true"/><small className="skeleton-text short" aria-hidden="true"/><span className="sr-only">Loading your profile</span></>
      :<><span>{session?(name||'Signed in'):'Guest'}</span><small>{session?subtitle:'Not signed in'}</small></>}</span></>;
  return <aside className="bank-sidebar" aria-label="UBS Connect">
    <nav className="sidebar-group" aria-label="Pages"><span className="eyebrow">UBS Connect</span>
      {pages.map(page=><button key={page.view} data-testid={page.testid} aria-label={label(page)} aria-current={page.view===current?'page':undefined} className={page.view===current?'sidebar-current':''} onClick={page.onSelect}>
        <Icon name={page.icon}/><span className="nav-label">{page.label}</span>{marker(page)}</button>)}
    </nav>
    <div className="sidebar-session" data-testid="sidebar-profile">
      {session&&menu?<AccountMenu className="sidebar-account" placement="up" label={profile} items={menu}/>:<div className="sidebar-account static">{profile}</div>}
      {session&&onSignOut&&<button className="icon-button sidebar-signout" aria-label="Sign out" title="Sign out" onClick={onSignOut}><Icon name="logout"/></button>}
      {/* Signing in is offered in the same place as signing out, so the sidebar never leaves a guest stuck. */}
      {!session&&onSignIn&&<button className="primary-button sidebar-signin" data-testid="sidebar-sign-in" onClick={onSignIn}>Sign in<Icon name="arrow"/></button>}</div>
  </aside>;
}

// Narrow screens: the same pages as a bottom tab bar (Actions is a tab there; the account menu drops it).
export function TabBar({current,pages}) {
  return <nav className="tab-bar" aria-label="Pages" style={pages.length!==5?{gridTemplateColumns:`repeat(${pages.length},minmax(0,1fr))`}:undefined}>{pages.map(page=><button key={page.view} data-testid={`tab-${page.view}`} aria-label={label(page)} aria-current={page.view===current?'page':undefined} onClick={page.onSelect}>
    <span className="tab-icon"><Icon name={page.icon}/>{marker(page)}</span><span>{page.short}</span></button>)}</nav>;
}
