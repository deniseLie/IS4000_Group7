import {useEffect,useRef,useState} from 'react';
import Icon from './Icon';
import {supabase} from '../lib/supabase';
import {confirmAction,loadActions,rejectAction} from '../lib/actions';
import {appointmentTime} from '../lib/appointmentData';
import {TOPICS} from '../lib/meetingRequests';
import {INSIGHT_ACTIONS,insightSentence,line} from '../lib/talkingPoints';
import {consentCategoryText} from '../lib/consentData';
import {displayName,formatDate,formatDateTime,formatMoney,formatTime} from '../lib/format';
import {POSSESSION,possessionLabel} from '../lib/disputeData';
import {cacheOwner,cached,remember} from '../lib/cache';

function commandTitle(command) {
  if(command.type==='card.temporary_block')return `Freeze card ending ${command.target.last4}`;
  if(command.type==='card.dispute')return `Dispute draft for card ending ${command.target.last4}`;
  if(command.type==='card.unblock')return command.staff?`Staff reactivation of card ending ${command.target.last4}`:`Unfreeze card ending ${command.target.last4}`;
  if(command.type==='card.cancel_permanently')return command.staff?`Staff cancellation of card ending ${command.target.last4}`:`Permanently cancel card ending ${command.target.last4}`;
  if(command.type==='handoff.claim')return 'Staff claimed a demo support handoff';
  if(command.type==='handoff.close')return 'Staff closed a demo support handoff';
  if(command.type==='handoff.create')return 'Record a demo support handoff';
  if(command.type==='appointment.hold')return 'Hold a appointment';
  if(command.type==='appointment.confirm')return 'Confirm a appointment';
  if(command.type==='appointment.cancel')return 'Cancel a appointment';
  if(command.type==='consent.request')return 'Record a data-sharing consent request';
  if(command.type==='consent.grant')return 'Grant reviewed data-sharing consent';
  if(command.type==='consent.revoke')return 'Revoke a recorded data-sharing grant';
  if(command.type==='compliance.update_checklist_item')return 'Save a checklist preparation mark';
  if(command.type==='compliance.answer_request')return 'Answer a question from the bank';
  if(command.type==='document.register')return 'Record a private document upload';
  if(command.type==='document.submit')return 'Submit a checked demo document for review';
  if(command.type==='requests.create')return 'Submit a relationship request';
  if(command.type==='ticket.create')return `Raise a request: ${command.target.category_label}`;
  if(command.type==='agenda.save')return 'Save a private agenda draft';
  if(command.type==='rm.share_summary')return 'Share a saved agenda snapshot';
  if(command.type==='meeting.request')return 'Send a meeting request to your relationship manager';
  if(command.type==='meeting.withdraw')return 'Withdraw a meeting request';
  if(command.type==='meeting.counter_reply')return command.target.reply==='accept'?'Accept the time your relationship manager suggested':'Decline the time your relationship manager suggested';
  if(INSIGHT_ACTIONS.includes(command.type))return insightSentence(command.type,command.target);
  throw new Error('This action type has no review title. Reload its recorded status.');
}

function receiptText(item) {
  if(item.receipt.outcome==='failed'&&item.command.type==='rm.share_summary')return 'This snapshot was not shared. The saved draft, assigned recipient or reviewed consent changed. Reopen Data sharing before proposing another snapshot.';
  if(item.receipt.outcome==='failed')return 'This command did not change the target. Its state changed before execution.';
  if(item.command.type==='card.temporary_block')return 'You froze this card; new card payments are declined until you unfreeze it on Overview under Cards.';
  if(item.command.type==='card.dispute')return 'This command recorded the reviewed dispute draft and your answer about the card for bank staff review. Staff decide any refund or cancellation; nothing has been refunded.';
  const noted=item.receipt.result.handoffs_noted?.length?' Bank staff reviewing a case for this card can see this change.':'';
  if(item.command.type==='card.unblock')return item.command.staff?'A verified demo support session reactivated this card.':'You unfroze this card; new card payments can go through again.'+noted;
  if(item.command.type==='card.cancel_permanently')return item.command.staff?'A verified demo support session permanently cancelled this card.':'You permanently cancelled this card. It cannot be reactivated.'+noted;
  if(item.command.type==='handoff.claim')return 'A verified demo support session claimed this support case.';
  if(item.command.type==='handoff.close')return 'A verified demo support session closed this support case. This does not change a card or reverse a transaction.';
  if(item.command.type==='handoff.create')return 'A support handoff is recorded in the demo. There is no staffed support queue.';
  if(item.command.type==='appointment.hold')return 'This command recorded a ten-minute appointment hold. Check current appointments before confirming.';
  if(item.command.type==='appointment.confirm')return 'This command confirmed the appointment. Check current appointments for its latest status. No real meeting or joining link is connected.';
  if(item.command.type==='appointment.cancel')return 'This command cancelled the appointment.';
  if(item.command.type==='consent.request')return 'This command recorded a consent request. It did not grant consent or share data.';
  if(item.command.type==='consent.grant')return 'This command granted the reviewed consent scope. Check Data sharing for its current status. Granting consent does not itself share data.';
  if(item.command.type==='consent.revoke')return 'This command revoked the reviewed grant. Other active grants remain until separately revoked or expired. Previously shared records are not erased.';
  if(item.command.type==='compliance.update_checklist_item')return 'This command saved your preparation mark only. It did not submit or verify a document or change the bank review status. Reload Records for the current mark.';
  if(item.command.type==='document.register')return 'This command recorded a private uploaded file. It did not accept the document for the bank, complete a preliminary check or change the review case status. Reload Records for its current status.';
  if(item.command.type==='document.submit')return 'This command submitted the checked file against its requested item. It is awaiting bank review, not accepted or approved.';
  if(item.command.type==='ticket.create')return `${item.receipt.result.created?'Recorded':'You already had an open request of this kind, so it was reused'}: ${item.receipt.result.reference}. The ${item.receipt.result.owner_team.toLowerCase()} decides the outcome, not the assistant. Check Requests for its status.`;
  if(item.command.type==='requests.create')return 'This command recorded the reviewed request with status sent. This does not mean the service is fulfilled or a real advisor was contacted. Check Requests for its current status.';
  if(item.command.type==='agenda.save')return 'This command saved a private agenda draft. It did not share data. Check Data sharing for the current draft version.';
  if(item.command.type==='rm.share_summary')return 'This command recorded the reviewed snapshot for the relationship manager. Later edits or consent revocation do not erase that shared copy. No real advisor was contacted.';
  if(item.command.type==='meeting.request')return `Your meeting request was sent. Your relationship manager answers by ${item.receipt.result.respond_by_text} (Singapore time). Follow it in Meetings.`;
  if(item.command.type==='meeting.withdraw')return 'You withdrew this meeting request. No meeting was booked.';
  if(item.command.type==='meeting.counter_reply')return item.receipt.result.reply==='accept'?`Your meeting is booked${item.receipt.result.when?` for ${item.receipt.result.when}`:''}. You can see it in Meetings.`:'You declined the suggested time and the request was closed. No meeting was booked.';
  if(item.command.type==='insight.share')return `Your relationship manager can now see “${line(item.receipt.result)}”${item.receipt.result.notified?' and has a notice in their workspace':''}. You can remove it under Data sharing.`;
  if(item.command.type==='insight.delete')return 'This topic and the words it came from were deleted. Your relationship manager no longer sees it.';
  if(item.command.type==='insight.mute')return 'This topic will not be suggested again from your chats. You can resume it under Data sharing.';
  if(item.command.type==='insight.resume')return item.receipt.result.topic?'This topic can be suggested again from your chats.':'Topic suggestions from your chats are on again.';
  throw new Error('This action type has no verified receipt description.');
}

function groupOf(command) {
  const kind=command.type.split('.')[0];
  return kind==='card'?'Cards':['compliance','document'].includes(kind)?'Compliance':['consent','agenda','rm','insight'].includes(kind)?'Data sharing':['appointment','meeting'].includes(kind)?'Appointments':['requests','ticket'].includes(kind)?'Requests':'Support';
}
// Plain-language card heading and summary; the exact recorded fields stay one click away under "Details".
function plainTitle(command) {
  const t=command.target;
  switch(command.type) {
    case 'card.temporary_block':return `Freeze card ending ${t.last4}`;
    case 'card.dispute':return `Dispute ${t.items.length} charges on card ending ${t.last4}`;
    case 'card.unblock':return command.staff?`Card ending ${t.last4} reactivated`:`Unfreeze card ending ${t.last4}`;
    case 'card.cancel_permanently':return command.staff?`Card ending ${t.last4} cancelled`:`Cancel card ending ${t.last4} permanently`;
    case 'compliance.update_checklist_item':return t.item_label;
    case 'compliance.answer_request':return t.question;
    case 'document.register':return t.item_label||'Document upload';
    case 'document.submit':return t.item_label;
    case 'requests.create':return `Request to ${displayName(t.recipient_name)}`;
    case 'ticket.create':return t.category_label;
    case 'agenda.save':return 'Handover note draft';
    case 'rm.share_summary':return `Handover note shared with ${displayName(t.recipient_name)}`;
    case 'consent.request':case 'consent.grant':return 'Relationship manager data sharing';
    case 'consent.revoke':return 'Withdraw data-sharing consent';
    case 'appointment.hold':case 'appointment.confirm':case 'appointment.cancel':return `Meeting on ${appointmentTime(t.starts_at)}`;
    case 'meeting.request':return 'Meeting request to your relationship manager';
    default:return command.type.startsWith('handoff.')?'Support handoff':commandTitle(command);
  }
}
function plainSummary(command) {
  const t=command.target,mark=value=>value.replaceAll('_',' '),who=t.recipient_name?displayName(t.recipient_name):t.recipient;
  switch(command.type) {
    case 'card.temporary_block':return 'Freezes this card so no new payments go through. You can unfreeze it yourself on Overview under Cards.';
    case 'card.dispute':return `Sends these charges to bank staff for review: ${t.items.map(charge).join('; ')}. Staff decide any refund.`;
    case 'card.unblock':return command.staff?'':'Unfreezes this card so new payments go through again. Only unfreeze it if you have the card and it is safe.';
    case 'card.cancel_permanently':return command.staff?'':'Permanently cancels this card. This cannot be undone: the card can never be reactivated.';
    case 'compliance.answer_request':return `Your answer to "${t.question}" goes to the bank for review.`;
    case 'compliance.update_checklist_item':return `Your preparation mark changes from ${mark(t.expected_client_mark)} to ${mark(t.client_mark)} for ${t.case_title}. The bank status stays ${mark(t.submission_status)}.`;
    case 'document.register':return `${t.file_name} (${(t.size_bytes/1048576).toFixed(2)} MB) stored privately for ${t.case_title}.`;
    case 'document.submit':return `${t.file_name} sent to the bank for review.`;
    case 'requests.create':return `“${t.what}” · ${t.urgency} urgency${t.deadline?` · requested by ${formatDate(t.deadline)}`:''}.`;
    case 'ticket.create':return `“${t.summary}” · goes to the ${t.owner_team.toLowerCase()}, who decide.`;
    case 'agenda.save':return `Private draft for ${who} (revision ${t.expected_revision+1}). Nothing is shared.`;
    case 'rm.share_summary':return `Shares your saved note (revision ${t.agenda_revision}) with ${who}: ${consentCategoryText(t.categories)}.`;
    case 'consent.request':return `Ask to let ${who} see ${consentCategoryText(t.categories)} for ${t.duration_days} days.`;
    case 'consent.grant':return `Lets ${who} see ${consentCategoryText(t.categories)}${t.expires_at?` until ${formatDate(t.expires_at)}`:''}. Other records stay restricted.`;
    case 'consent.revoke':return `Stops ${who} seeing ${consentCategoryText(t.categories)} from now on.`;
    case 'appointment.hold':case 'appointment.confirm':case 'appointment.cancel':return `${appointmentTime(t.starts_at)} – ${formatTime(t.ends_at)} (Singapore time) · ${mark(t.format)}.`;
    case 'meeting.request':return `“${t.purpose}” · ${t.topics.map(topic=>TOPICS[topic]).join(', ')} · ${mark(t.format)} · times that suit you: ${t.preferred_times.map(time=>appointmentTime(time)).join('; ')} (Singapore time).`;
    case 'handoff.create':return t.summary;
    default:return '';
  }
}
const shortDate=formatDateTime;
const charge=item=>`${formatDate(item.date)} ${item.merchant} ${formatMoney(item.amount,item.currency)}`;
// Review wording per type; an unknown type gets neutral wording rather than another action's.
const REVIEW={'card.temporary_block':['Confirming freezes this card: new payments are declined until you unfreeze it. Rejecting leaves it unchanged. This does not reverse a transaction or cancel the card.','card','Freeze card'],
  'card.unblock':['Confirming unfreezes this card so new payments can go through. You can only unfreeze a card you froze yourself while no fraud case or replacement is open. Rejecting leaves it frozen.','card','Unfreeze card'],
  'card.cancel_permanently':['Confirming permanently cancels this card. This cannot be undone: it can never be reactivated, and a replacement card is a separate request to the bank. Rejecting leaves the card unchanged.','permanent card cancellation','Cancel card permanently'],
  'card.dispute':['Confirming sends this dispute draft and your answer about the card to bank staff, who decide any refund or cancellation. Nothing is refunded now. Rejecting sends nothing.','dispute draft','Send dispute draft'],
  'requests.create':['Confirming records these exact request details for the displayed recipient. It does not fulfil the request, guarantee its deadline or perform a financial transaction. Rejecting submits nothing.','relationship request','Submit reviewed request'],
  'ticket.create':['Confirming records this request with a reference number for the team shown. The assistant does not approve, reject or predict the outcome; that team decides. Rejecting records nothing.','request','Submit request'],
  'rm.share_summary':['Confirming shares exactly this saved snapshot with the displayed recipient. Consent and the saved revision are rechecked. Rejecting shares nothing.','saved agenda snapshot and consent','Confirm sharing'],
  'consent.grant':['Confirming grants only the recipient, purpose, categories and expiry displayed above. This does not share data.','data-sharing scope','Confirm consent grant'],
  'consent.revoke':['Confirming revokes this specific grant. Other grants continue until separately revoked or expired, and earlier sharing is not erased.','data-sharing scope','Confirm revocation'],
  'appointment.confirm':['Confirming books this time only while its hold remains active. Review the date, time and format above. No real meeting or joining link is connected.','appointment','Confirm booking'],
  'appointment.cancel':['Confirming cancels this appointment and releases its time.','appointment','Confirm cancellation'],
  'meeting.request':['Confirming sends this meeting request to your relationship manager, who accepts a time, suggests another or replies in a message. Nothing is booked until then. Rejecting sends nothing.','meeting request','Send request'],
  'insight.share':['Confirming lets your relationship manager see only the topic line above, never your messages. You can remove it at any time under Data sharing. Rejecting shares nothing.','topic','Let her know']};
const review=type=>REVIEW[type]||['Confirming records the change shown above. Rejecting leaves it unchanged.','action','Confirm'];
// Exports only what this panel already loaded: one row per recorded action and its receipt.
function exportCsv(items) {
  const quote=value=>`"${String(value??'').replaceAll('"','""')}"`;
  const rows=[['command_id','action','group','state','proposed_at','receipt_id','receipt_outcome','receipt_created_at'],...items.map(({command,receipt})=>[command.command_id,commandTitle(command),groupOf(command),command.state,command.proposed_at,receipt?.receipt_id,receipt?.outcome,receipt?.created_at])];
  const link=document.createElement('a');link.href=URL.createObjectURL(new Blob([rows.map(row=>row.map(quote).join(',')).join('\n')],{type:'text/csv'}));
  link.download='demobank-action-receipts.csv';link.click();setTimeout(()=>URL.revokeObjectURL(link.href),1000);
}


// Plain-language activity: one sentence of what happened, one line of detail, and a status only when it is not simply done.
const QUESTION=/^(?:\[[^\]]{1,60}\]\s*)?Client question for you:\s*/;
function activity(command) {
  const t=command.target;
  switch(command.type) {
    case 'document.register':return ['upload',`Uploaded ${t.file_name}`,t.item_label?`For ${t.item_label}. Not sent to the bank yet.`:'Stored privately.'];
    case 'document.submit':return ['send',`Sent ${t.item_label} to the bank`,`${t.file_name} · waiting for the bank's review`];
    case 'compliance.answer_request':return ['send','Answered a question from the bank',`${t.question} · waiting for the bank's review`];
    case 'compliance.update_checklist_item':return ['check',`Marked ${t.item_label} as ${t.client_mark==='prepared'?'ready':'not ready'}`,'Your own checklist mark. It does not send anything to the bank.'];
    case 'handoff.create':{
      const summary=t.summary||'';
      if(t.reason==='card_lost')return ['shield','Lost or stolen card reported to the fraud team','They will contact you, block the card if needed and arrange a replacement.'];
      if(t.reason==='card_verification'||t.reason==='card_dispute')return ['shield','Card case sent to the fraud team','They will check your identity and the charges.'];
      if(QUESTION.test(summary))return ['people','Asked your relationship manager',`“${summary.replace(QUESTION,'').split(' | Earlier in this chat:')[0]}”`];
      if(/withheld/i.test(summary))return ['people','Passed a question to your relationship manager',"Part of an answer couldn't be checked, so your relationship manager will follow up."];
      if(/compliance/i.test(summary))return ['people','Asked for help with your compliance review','Your relationship manager will follow up.'];
      return ['people','Asked to talk to a person','Your relationship manager will follow up.'];
    }
    case 'handoff.claim':return ['people','The bank picked up your case',''];
    case 'handoff.close':return ['people','The bank closed your case',''];
    case 'ticket.create':return ['clip',`Raised a request: ${t.category_label}`,t.summary];
    case 'requests.create':return ['people',`Sent a request to ${displayName(t.recipient_name)}`,t.what];
    case 'meeting.request':return ['calendar','Asked your relationship manager for a meeting',`“${t.purpose}”`];
    case 'meeting.withdraw':return ['calendar','Withdrew a meeting request',''];
    case 'insight.share':case 'insight.delete':case 'insight.mute':case 'insight.resume':return ['shield',insightSentence(command.type,t),''];
    case 'meeting.counter_reply':return ['calendar',t.reply==='accept'?'Accepted the time your relationship manager suggested':'Declined the time your relationship manager suggested',''];
    case 'card.temporary_block':return ['card',`Freeze card ending ${t.last4}`,'Stops new payments on this card until it is checked.'];
    case 'card.dispute':return ['card',`Dispute ${t.items.length} charges on card ending ${t.last4}`,t.items.map(charge).join('; ')];
    case 'card.unblock':return ['card',command.staff?`The bank reactivated card ending ${t.last4}`:`Unfreeze card ending ${t.last4}`,''];
    case 'card.cancel_permanently':return ['card',command.staff?`The bank cancelled card ending ${t.last4}`:`Cancel card ending ${t.last4} for good`,command.staff?'':'This cannot be undone.'];
    default:return ['document',plainTitle(command),plainSummary(command)];
  }
}
function chip(command,receipt) {
  if(command.state==='proposed')return ['Waiting for you','wait'];
  if(command.state==='confirmed')return ['In progress','wait'];
  if(command.state==='rejected')return ['You cancelled this','muted'];
  if(command.state==='expired')return ['Expired','muted'];
  if(command.state==='failed'||receipt?.outcome==='failed')return ["Didn't go through",'bad'];
  return null;
}
function meaning(item) {
  const {command,receipt}=item;
  if(!receipt)return '';
  if(receipt.outcome==='failed')return 'Nothing changed, because the record changed before this could run.';
  switch(command.type) {
    case 'document.register':return 'Your file is saved privately. It goes to the bank once our quick check finds it complete and you press Send.';
    case 'document.submit':return 'The bank has the file. Only the bank can accept it; you will see the outcome in Periodic review and your Inbox.';
    case 'compliance.update_checklist_item':return 'Only your own checklist mark changed.';
    case 'compliance.answer_request':return 'Your answer was sent to the bank. The bank decides whether it is enough.';
    case 'handoff.create':return 'Your relationship manager has the question and will reply. Follow it in Requests.';
    case 'ticket.create':return `Reference ${receipt.result.reference}. ${receipt.result.owner_team} decides; follow it in Requests.`;
    default:return receiptText(item);
  }
}
function dayLabel(value) {
  const day=new Date(value),today=new Date(),key=d=>d.toDateString(),yesterday=new Date(today);yesterday.setDate(today.getDate()-1);
  return key(day)===key(today)?'Today':key(day)===key(yesterday)?'Yesterday':formatDate(value);
}
const FILTERS=[['all','All'],['Requests','Requests'],['Compliance','Documents'],['Cards','Cards'],['Appointments','Meetings'],['Data sharing','Data sharing']];
const inFilter=(item,filter)=>filter==='all'||(filter==='pending'?item.command.state==='proposed':filter==='Requests'?['Requests','Support'].includes(groupOf(item.command)):groupOf(item.command)===filter);

// Reopening shows the last loaded list at once; decisions stay disabled (busy) until the refreshed list arrives.
export default function ActionsPanel() {
  const [items,setItems]=useState(()=>cached('actions'));
  const [selected,setSelected]=useState(null);
  const [acknowledged,setAcknowledged]=useState(false),[answer,setAnswer]=useState('');
  const [busy,setBusy]=useState(false),[deciding,setDeciding]=useState(false);
  const [error,setError]=useState('');
  const scope=useRef(cacheOwner());
  useEffect(()=>{if(items)remember('actions',items,scope.current);},[items]);
  const active=useRef(null);
  useEffect(()=>{
    const controller=new AbortController();active.current=controller;
    refresh(controller);
    return ()=>active.current?.abort();
  },[]);
  async function token() {
    const {data,error:failure}=await supabase.auth.getSession();
    if(failure)throw failure;
    if(!data.session)throw new Error('Please sign in again to review actions.');
    return data.session.access_token;
  }
  async function refresh(controller) {
    setBusy(true);setError('');setSelected(null);setAcknowledged(false);setAnswer('');
    try {
      const result=await loadActions(await token(),controller.signal);
      if(!controller.signal.aborted)setItems(result);
    } catch(failure) {
      if(failure.name!=='AbortError'&&!controller.signal.aborted){setError(failure.message);setItems(null);}
    } finally {if(!controller.signal.aborted)setBusy(false);}
  }
  async function submit(operation,commandId) {
    const controller=new AbortController();active.current=controller;
    setBusy(true);setDeciding(true);setError('');
    try {
      const result=await operation(commandId,await token(),controller.signal);
      if(!controller.signal.aborted){
        setItems(previous=>previous.map(item=>item.command.command_id===commandId?result:item));setSelected(null);setAcknowledged(false);setAnswer('');
        const recorded=await loadActions(await token(),controller.signal);
        if(!controller.signal.aborted)setItems(recorded);
      }
    } catch(failure) {if(failure.name!=='AbortError'&&!controller.signal.aborted)setError(failure.message);}
    finally {if(!controller.signal.aborted){setBusy(false);setDeciding(false);}}
  }
  const [filter,setFilter]=useState('all'),[query,setQuery]=useState('');
  const all=items||[];
  const needle=query.trim().toLowerCase();
  const visible=[...all].sort((a,b)=>(a.command.state==='proposed'?0:1)-(b.command.state==='proposed'?0:1)||Date.parse(b.receipt?.created_at||b.command.proposed_at)-Date.parse(a.receipt?.created_at||a.command.proposed_at))
    .filter(item=>inFilter(item,filter)&&(!needle||[...activity(item.command).slice(1),item.receipt?.receipt_id||'',formatDate(item.command.proposed_at)].join(' ').toLowerCase().includes(needle)));
  // Waiting for you to confirm: the same request asked more than once is one row (one confirmation sends it; the
  // older copies are cancelled in the same step). Everything else is a simple history by day.
  const proposed=all.filter(item=>item.command.state==='proposed').sort((a,b)=>Date.parse(b.command.proposed_at)-Date.parse(a.command.proposed_at));
  const groups=[];for(const item of proposed){const key=`${item.command.type}|${activity(item.command)[1]}`,found=groups.find(g=>g.key===key);if(found)found.items.push(item);else groups.push({key,items:[item]});}
  const history=visible.filter(item=>item.command.state!=='proposed');
  const days=[];for(const item of history){const label=dayLabel(item.receipt?.created_at||item.command.proposed_at);const last=days[days.length-1];if(last&&last[0]===label)last[1].push(item);else days.push([label,[item]]);}
  async function confirmGroup(group) {
    const [latest,...older]=group.items,command=latest.command;
    await submit(command.type==='card.dispute'?(id,key,signal)=>confirmAction(id,key,signal,{card_in_possession:answer}):confirmAction,command.command_id);
    for(const item of older)await submit(rejectAction,item.command.command_id);
  }
  return <section className="app-page-body activity-page" aria-label="Activity" data-testid="actions-page">
    <header className="page-header"><div><span className="eyebrow">Your account</span><h1>Activity</h1><p>What you asked for or confirmed, newest first. Nothing happens until you confirm it.</p></div>
      <div className="page-header-actions"><button className="link-button activity-csv" disabled={!all.length} onClick={()=>exportCsv(all)}>Download as a spreadsheet</button>
      <button data-testid="reload-actions" className="icon-button" aria-label="Refresh" title="Refresh" disabled={busy} onClick={()=>{const controller=new AbortController();active.current=controller;refresh(controller);}}><Icon name="refresh"/></button></div></header>
    {busy&&<p className="loading" role="status">{deciding?'Saving your decision…':items?'Updating…':'Loading your activity…'}</p>}
    {busy&&!items&&!deciding&&<div className="loading-list" aria-hidden="true">{[0,1,2].map(key=><span key={key} className="skeleton-card large"/>)}</div>}
    {error&&<p role="alert" data-testid="actions-error">{error} Refresh, then try again.</p>}
    {groups.length>0&&<section className="act-waiting" aria-label="Waiting for you to confirm"><h2>Waiting for you to confirm</h2>
      {groups.map(group=>{const item=group.items[0],command=item.command,[,plain,detail]=activity(command),chosen=selected===command.command_id;
        const title=command.type==='handoff.create'?'Send your question to your relationship manager':plain;
        const times=group.items.map(x=>formatTime(x.command.proposed_at)).reverse().join(' and ');
        return <div key={group.key} className="act-waiting-row" data-command-id={command.command_id}>
          <div className="act-waiting-line"><div className="act-waiting-text"><strong>{title}</strong>
            <small>{group.items.length>1?`You asked ${group.items.length===2?'twice':`${group.items.length} times`} (${times}) · one confirmation sends it`:detail} · open until {formatTime(command.expires_at)}</small></div>
            {!chosen&&<><button className="primary-button" data-testid="review-command" disabled={busy||!!error||item.workflow&&!item.workflow.ready} onClick={()=>{setSelected(command.command_id);setAcknowledged(false);setAnswer('');}}>Review and confirm</button>
              <button className="link-button" data-testid="reject-command" disabled={busy||!!error} onClick={async()=>{for(const x of group.items)await submit(rejectAction,x.command.command_id);}}>Don’t do this</button></>}</div>
          {chosen&&<div className="command-review act-review" data-testid="command-review">
            {detail&&group.items.length>1&&<p>{detail}</p>}
            <p>{review(command.type)[0]}</p>
            {command.type==='card.dispute'&&<fieldset className="dispute-answer" data-testid="command-dispute-answer"><legend>Do you still have the card?</legend>
              {POSSESSION.map(([key,label])=><label key={key}><input type="radio" name={`possession-${command.command_id}`} value={key} checked={answer===key} disabled={busy||!!error} onChange={()=>setAnswer(key)}/> {label}</label>)}</fieldset>}
            <label className="act-ack"><input type="checkbox" data-testid="acknowledge-command" checked={acknowledged} disabled={busy||!!error} onChange={event=>setAcknowledged(event.target.checked)}/> I have checked the details above.</label>
            <div className="act-actions"><button className="primary-button" data-testid="confirm-command" disabled={busy||!!error||!acknowledged||command.type==='card.dispute'&&!answer} onClick={()=>confirmGroup(group)}><Icon name="check"/>{review(command.type)[2]}</button>
              <button className="bank-chat-logout" onClick={()=>setSelected(null)}>Back</button></div>
          </div>}
        </div>;})}
    </section>}
    {all.length>0&&<div className="act-filters"><div className="act-chips" role="group" aria-label="Show">{FILTERS.map(([key,label])=>{const count=all.filter(item=>item.command.state!=='proposed'&&inFilter(item,key)).length;
      return (key==='all'||count>0)&&<button key={key} type="button" className={`mtg-chip ${filter===key?'on':''}`} aria-pressed={filter===key} onClick={()=>setFilter(key)}>{label}</button>;})}</div>
      <label className="act-search activity-search"><Icon name="search"/><input aria-label="Filter actions" placeholder="Search activity" value={query} onChange={event=>setQuery(event.target.value)}/></label></div>}
    {items?.length===0&&<p className="act-empty" data-testid="actions-empty">Nothing yet. Uploads, requests and anything you confirm will show up here.</p>}
    {items?.length>0&&history.length===0&&!groups.length&&<p className="act-empty">Nothing matches this view.</p>}
    {days.length>0&&<div data-testid="commands-list" className="act-history tab-fade" key={filter}>{days.map(([label,group])=><section key={label} className="act-day"><h2>{label}</h2>
     <ul>{group.map(item=>{const command=item.command,receipt=item.receipt,[,title,detail]=activity(command),status=chip(command,receipt);
      return <li key={command.command_id} data-command-id={command.command_id}><details className="act-row">
        <summary><span className="act-row-text"><strong>{title}</strong>{(detail||status)&&<small>{[detail,status&&!['In progress'].includes(status[0])?status[0]:null].filter(Boolean).join(' · ')}</small>}</span>
          <time dateTime={receipt?.created_at||command.proposed_at}>{formatTime(receipt?.created_at||command.proposed_at)}</time></summary>
        <div className="act-detail">
          {item.workflow?.state==='failed'&&<p data-testid="command-workflow">Your decision is saved, but the chat reply didn't finish.</p>}
          {receipt&&<p>{meaning(item)}</p>}
          {command.type==='card.dispute'&&<div data-testid="command-dispute"><ul>{command.target.items.map(entry=><li key={entry.transaction_id}>{charge(entry)}</li>)}</ul>{command.answers&&<p>Do you still have the card? {possessionLabel(command.answers.card_in_possession)}.</p>}</div>}
          {command.type==='ticket.create'&&<div data-testid="command-ticket">{Object.keys(command.target.details).length>0&&<ul>{Object.entries(command.target.details).map(([name,value])=><li key={name}>{name.replaceAll('_',' ')}: {value}</li>)}</ul>}<p>Decided by: {command.target.decided_by}</p></div>}
          {command.type==='document.register'&&<p data-testid="command-document">{command.target.file_name} · {(command.target.size_bytes/1024).toFixed(0)} KB · {command.target.case_title}</p>}
          {['card.unblock','card.cancel_permanently'].includes(command.type)&&!command.staff&&<p data-testid="command-card-change">{plainSummary(command)}</p>}
          {(command.type.startsWith('consent.')||command.type.startsWith('appointment.')||['agenda.save','rm.share_summary','requests.create','meeting.request'].includes(command.type))&&<p>{plainSummary(command)}</p>}
          <p className="act-meta">{formatDateTime(receipt?.created_at||command.proposed_at)} · <span data-testid="command-state">{command.state}</span>{receipt&&<> · reference <code data-testid="command-receipt" title={receipt.receipt_id}>{receipt.receipt_id.slice(0,8)}</code></>}</p>
        </div></details></li>;})}</ul></section>)}</div>}
  </section>;
}
