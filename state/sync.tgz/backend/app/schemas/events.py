"""SSE event payloads for POST /chat (docs/architecture.md §4). Additive to today's status, answer, done, error."""
from datetime import datetime
from typing import Literal
from uuid import UUID
from pydantic import AwareDatetime,BaseModel,ConfigDict,Field,StrictBool,StrictInt
from app.schemas.contracts import AnswerKind, Domain, Priority

Origin = Literal['ai', 'safety', 'validation']


class StatusEvent(BaseModel):  # not sent: /chat sends a plain status string on both pipelines
    stage: Literal['checking', 'planning', 'retrieving', 'validating']


class Source(BaseModel):  # schemas/knowledge.KnowledgeSection.source() and answers.pinned()
    id: str
    title: str
    url: str | None
    version: str
    publisher: str | None = None
    reference_url: str | None = None
    checked_on: str | None = None
    review_due: str | None = None
    current: bool = True


class ActionRequiredEvent(BaseModel):
    model_config = ConfigDict(extra='forbid')
    command_id: UUID
    type: str
    summary: str
    expires_at: datetime
    optional: bool = False  # 0114: a switch in the group, off unless she turns it on (offers.optional)


class AnswerSection(BaseModel):  # one per task, priority order
    model_config = ConfigDict(extra='forbid')
    task_id: str
    domain: Domain
    priority: Priority
    answer_kind: AnswerKind = 'banking'
    answer: str
    sources: list[Source] = []
    needs_human: bool = False
    response_origin: Origin
    prompt_version: str | None = None
    pending_action: ActionRequiredEvent | None = None  # legacy single offer; read only from replies saved before card.dispute
    pending_actions: list[ActionRequiredEvent] = Field(default=[], max_length=2)  # v4 paused previews, read only from replies saved before phase 5; v5 never sets it
    decision: str | None = None  # fixed text for a recorded action outcome on this section's task


class PlannedSection(BaseModel):  # v5: a placeholder the client fills from the matching `section` event
    model_config = ConfigDict(extra='forbid')
    task_id: str = Field(min_length=1, max_length=40)
    domain: Domain
    priority: Priority


class PlanEvent(BaseModel):  # v5: the turn's tasks in priority order, sent once after the planner
    model_config = ConfigDict(extra='forbid')
    tasks: list[PlannedSection] = Field(min_length=1, max_length=5)


class OfferGroupEvent(BaseModel):  # v5: one reply's offers, confirmed or cancelled together (services/offers.py)
    model_config = ConfigDict(extra='forbid')
    offer_group: UUID
    expires_at: datetime
    offers: list[ActionRequiredEvent] = Field(min_length=1, max_length=10)


class AnswerEvent(BaseModel):  # today's answer object + optional sections
    answer: str
    sources: list[Source] = []
    privacy_warning: bool = False
    history_trimmed: bool = False
    disclaimer: str
    needs_human: bool = False
    source_check: str
    prompt_version: str | None = None
    response_origin: Origin
    sections: list[AnswerSection] | None = None
    offer: OfferGroupEvent | None = None  # v5: Confirm/Cancel buttons send offer_group (phase 6)
    care: bool = False  # RiskAssessment.care (2a): the UI shows Talk to a person instead of product or meeting chips


class WorkflowStatus(BaseModel):
    model_config=ConfigDict(extra='ignore')
    version: Literal['v2-actions-v1']
    turn_id: UUID
    session_id: UUID
    case_id: UUID
    customer_id: StrictInt
    state: Literal['awaiting_confirmation','running','failed','completed','cancelled']
    ready: StrictBool
    can_resume: StrictBool
    pending_commands: list[UUID]=Field(max_length=5)
    lease_expires_at: AwareDatetime | None
    error_code: Literal['resume_failed','cancelled','assistant_unavailable','interrupted'] | None
