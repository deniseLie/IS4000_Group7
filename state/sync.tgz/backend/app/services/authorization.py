"""Explicit tool policy. decide() is pure; require_permission() audits and enforces it.

Agent identity is attached by trusted backend code in RequestContext, never by model arguments.
Consent lookup and transactional action execution belong to their subsequent service stages.
"""
from collections.abc import Mapping
from pydantic import BaseModel, ConfigDict, Field, JsonValue, StrictInt, ValidationError
from app.schemas.contracts import Decision, Principal, RequestContext
from app.schemas.meeting_agents import MeetingAccess, MeetingRmAccess, MeetingWorkerAccess
from app.services import audit
from app.services.agents import registry
from app.services.agents.registry import TOOLS

PUBLIC_TOOLS = frozenset({'kb.search','tickets.categories'})
AUTO_TYPES = frozenset({'handoff.create','appointment.hold','compliance.update_checklist_item','agenda.save','consent.request','document.register','document.submit','compliance.answer_request',
    'insight.delete','insight.mute','insight.resume','insight.restore',  # 0108: her own talking-point controls (Data sharing); 0110: Undo
    'consent.decline_ask'})  # 0113: "Not now" to her RM's ask
# Card changes confirmed by the signed-in customer only; agents are refused (customer_only_action). Since 0081
# card.cancel_permanently is bank-only (BANK_ONLY_CARD_ACTIONS, checked first), so only card.unblock is hers (0096).
# Staff run both types through scripts/staff_support.py, which never goes through this policy.
CUSTOMER_CARD_CHANGES = frozenset({'card.unblock','card.cancel_permanently'})
CONFIRM_TYPES = frozenset({'card.temporary_block','card.dispute','card.order_replacement','appointment.confirm','appointment.cancel',
    'requests.create','rm.share_summary','consent.grant','consent.revoke','ticket.create',
    'meeting.request','meeting.withdraw','meeting.counter_reply','insight.share'}) | CUSTOMER_CARD_CHANGES  # meeting.*: 0106; insight.share: 0108
STAFF_TYPES = frozenset({'card.unblock','card.cancel_permanently','handoff.claim','handoff.close'})
# 0096 (CR19): the client freezes and unfreezes her own card again (card.temporary_block, card.unblock; SQL refuses an
# unfreeze of a card the bank froze). Cancelling and the fraud dispute draft stay the bank's. No agent proposes any of them.
BANK_ONLY_CARD_ACTIONS = frozenset({'card.dispute','card.cancel_permanently'})
CLIENT_ONLY_CARD_ACTIONS = frozenset({'card.temporary_block','card.unblock'})
AGENT_ACTIONS = {
    'fraud':frozenset({'card.order_replacement'}),
    'relationship':frozenset({'appointment.hold','appointment.confirm','appointment.cancel','requests.create',
        'rm.share_summary','consent.grant','consent.revoke','meeting.request',
        'insight.share','insight.delete',  # the chat offers a meeting request (2a), Let-Sophie-know (0108, lane 2) and topic deletion (6e)
        'ticket.create'}),  # 0146: "stop recording my meetings" is a consent_withdrawal request (agents/consent_answers)
}
KNOWN_TOOLS = frozenset(tool for tools in TOOLS.values() for tool in tools) | AUTO_TYPES | CONFIRM_TYPES | STAFF_TYPES | {'compliance.workspace','documents.precheck','actions.read','actions.list','actions.create_case','consent.records','agenda.list','documents.list','documents.prepare_upload','documents.download','documents.inspect','notifications.list','notifications.read','appointments.meeting_options','tickets.list','tickets.categories','tickets.follow_up','tickets.attach','tickets.open_rm','meeting_requests.list','insights.read','insights.status','insights.record','consent.sharing','consent.access_log','consent.asks','customer.get_portfolio'}  # 0116: Overview only, no agent reads it


class PolicyResource(BaseModel):
    """Only a trusted customer scope affects policy; unrelated action fields are ignored."""
    model_config = ConfigDict(extra='ignore')
    customer_id: StrictInt | None = Field(default=None,gt=0)


class PolicyDenied(PermissionError):
    """A registered tool or action was refused before any service access."""


def meeting_decision(subject: Principal, action: str, resource: Mapping[str, JsonValue] | None, context: MeetingAccess) -> Decision:
    """Check the execution lane before connecting. SQL verifies live assignment, consent and queue leases."""
    spec = registry.MEETING_SPECS.get(context.agent)
    tool = next((tool for tool in spec.tools if tool.name == action), None) if spec else None
    if tool is None:return Decision(allow=False,reasons=['agent_tool_forbidden'])
    target = context.meeting_id if isinstance(context, MeetingRmAccess) else context.claim.meeting_id
    if resource is None or resource.get('meeting_id') != str(target):
        return Decision(allow=False,reasons=['meeting_scope_mismatch'])
    if tool.actor == 'assigned_rm':
        if not isinstance(context, MeetingRmAccess) or subject.kind != 'customer' or not subject.jwt or not subject.jwt.get_secret_value().strip():
            return Decision(allow=False,reasons=['meeting_rm_required'])
        if context.claims.sub != subject.user_id or context.claims.app_metadata.demobank_role != 'rm' or context.claims.app_metadata.rm_id is None:
            return Decision(allow=False,reasons=['meeting_rm_required'])
    elif not isinstance(context, MeetingWorkerAccess) or subject.kind != 'system' or context.claim.event_type != 'transcript.ready':
        return Decision(allow=False,reasons=['meeting_claim_required'])
    return Decision(allow=True,reasons=['explicit_rule'])


def decide(subject: Principal, action: str, resource: Mapping[str, JsonValue] | None, context: RequestContext | MeetingAccess | None) -> Decision:
    if action not in KNOWN_TOOLS and action not in registry.MEETING_TOOLS:return Decision(allow=False,reasons=['unknown_tool'])
    if context is None:return Decision(allow=False,reasons=['missing_context'])
    if subject != context.principal:return Decision(allow=False,reasons=['principal_mismatch'])
    if isinstance(context, (MeetingRmAccess, MeetingWorkerAccess)):
        return meeting_decision(subject,action,resource,context)
    if action in registry.MEETING_TOOLS:return Decision(allow=False,reasons=['meeting_execution_required'])
    try:
        scope = PolicyResource.model_validate(resource if resource is not None else {})
    except ValidationError:
        return Decision(allow=False,reasons=['invalid_resource_scope'])
    if subject.kind == 'system':return Decision(allow=False,reasons=['system_access_unconfigured'])
    if subject.kind == 'guest':
        if action not in PUBLIC_TOOLS:return Decision(allow=False,reasons=['guest_no_personal_data'])
        if scope.customer_id is not None:return Decision(allow=False,reasons=['customer_scope_mismatch'])
    else:
        if not subject.user_id or not subject.jwt or not subject.jwt.get_secret_value().strip():
            return Decision(allow=False,reasons=['customer_session_required'])
        if action not in PUBLIC_TOOLS and (subject.customer_id is None or subject.customer_id <= 0):
            return Decision(allow=False,reasons=['customer_session_required'])
        if scope.customer_id is not None and scope.customer_id != subject.customer_id:
            return Decision(allow=False,reasons=['customer_scope_mismatch'])
    # Cancelling and the fraud dispute draft are the bank's (0081); staff use scripts/staff_support.py.
    if action in BANK_ONLY_CARD_ACTIONS:return Decision(allow=False,reasons=['bank_only_action'])
    # Freezing is the client's own decision from her card controls (0096), never an agent's proposal.
    if action in CLIENT_ONLY_CARD_ACTIONS and context.agent is not None:return Decision(allow=False,reasons=['customer_only_action'])
    if action in STAFF_TYPES and action not in CUSTOMER_CARD_CHANGES:return Decision(allow=False,reasons=['staff_access_required'])
    if (spec:=registry.spec_for(context.agent)) is not None:  # v5: the agent catalogue is the allow-list
        if action not in registry.permissions(spec) and action not in spec.offers:return Decision(allow=False,reasons=['agent_tool_forbidden'])
    elif context.agent is not None:
        allowed = action in TOOLS[context.agent] or action in AGENT_ACTIONS.get(context.agent,frozenset())
        if not allowed:return Decision(allow=False,reasons=['agent_tool_forbidden'])
    obligations: list[str] = []
    if action == 'customer.get_credit_cards':obligations.append('mask:pan')
    # Every action a v5 agent offers waits for the client (services/offers.py, 0100); AUTO_TYPES run unconfirmed only from UI forms.
    if action in CONFIRM_TYPES or (spec is not None and action in spec.offers):obligations.append('require:confirmation')
    if action == 'rm.share_summary':obligations.append('require:consent:rm_brief')
    return Decision(allow=True,reasons=['explicit_rule'],obligations=obligations)


def require_permission(subject: Principal, action: str, resource: Mapping[str, JsonValue] | None, context: RequestContext | MeetingAccess) -> Decision:
    """Record ids and rule codes only; a denial raises before the caller opens a DB client."""
    decision = decide(subject,action,resource,context)
    actor = {'actor_type':'agent','actor_id':context.agent} if context.agent is not None else {}
    audit.add('policy','policy.decided','success' if decision.allow else 'denied',
        details={'tool':action if action in KNOWN_TOOLS or action in registry.MEETING_TOOLS else 'unregistered_tool','reasons':decision.reasons,'version':'v1'},**actor)
    if not decision.allow:raise PolicyDenied(f"Tool access denied: {decision.reasons[0]}")
    return decision


def require_tool(name: str, context: RequestContext) -> None:
    """A v5 agent may call only the model-facing tools in its spec; the service read then checks its own permission.
    Only refusals are audited here, so an allowed call records one policy decision, as before."""
    if (spec:=registry.spec_for(context.agent)) is None or name in spec.tools or name in spec.external:return
    audit.add('policy','policy.decided','denied',details={'tool':name if name in registry.TOOL_PERMISSION or name in registry.EXTERNAL else 'unregistered_tool',
        'reasons':['agent_tool_forbidden'],'version':'v1'},actor_type='agent',actor_id=context.agent)
    raise PolicyDenied('Tool access denied: agent_tool_forbidden')
